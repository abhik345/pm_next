export default function BlogDetailsLayout({ children }) {
    return (    
        <>
          {children}
        </>
    );
  }